---------------------------------

Hello there!

Seems like you are struggling with something..
In order to prevent some things there and there, AREDONE prepared you this little text document :)

---------------------------------
For installations:
Head to: 

1) C:\YOUR DIRECTORY\Steam\steamapps\common\Counter-Strike Global Offensive\csgo\resource\
2) Make a copy of overviews
3) Open overviews (C:\YOUR DIRECTORY\Steam\steamapps\common\Counter-Strike Global Offensive\csgo\resource\overviews)
4) Paste the .dds files, restart game and you are ready to rock!
5) It is recommended to use resolutions with height greater than 1024!!!
---------------------------------

Not feeling good with simpleradar? You can revert back using the backup you made in step 2 or by verifying integrity of game cache on steam

---------------------------------
Best experience radar settings: 
cl_radar_scale 0.5 or higher
cl_radar_rotate 1 but works with 0 aswell (some walls might be flickery with 0 and low radar scale)
cl_radar_always_centered 1 or 0 - doesnt matter
cl_radar_icon_scale_min 0.4
---------------------------------

ENJOY SIMPLERADAR, BECAUSE IT IS FREE AND YOU WILL NOT BE BANNED FOR USING IT!
Have a nice day and thank you for choosing and using our work! ♥ 

---------------------------------